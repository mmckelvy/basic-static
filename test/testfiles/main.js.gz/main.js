'use strict';

function hello() {
  console.log('hello');
}

hello();